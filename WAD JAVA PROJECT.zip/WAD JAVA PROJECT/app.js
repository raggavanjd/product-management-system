// Get form elements
function validatelo()
{
const loginForm = document.getElementById('login-form');
const usernameInput = document.getElementById('username').value;
const passwordInput = document.getElementById('password').value;
const errorMessage = document.getElementById('error-message');

// Hardcoded user credentials for demo purposes
const validUsername = "admin";
const validPassword = "12345";
if(usernameInput == validUsername && passwordInput==validPassword)
{
    alert("login successfull");
}
else{
    alert("Invalid username and password");
}
}
// Function to handle form submission
function handleLogin(event) {
  event.preventDefault();
  
  const enteredUsername = usernameInput.value.trim();
  const enteredPassword = passwordInput.value.trim();
  
  if (enteredUsername === validUsername && enteredPassword === validPassword) {
    // Simulate successful login
    alert("Login successful!");
    // Redirect to another page (example: dashboard.html)
    window.location.href = "dashboard.html";
  } else {
    // Show error message
    errorMessage.textContent = "Invalid username or password!";
  }
}

// Add event listener to handle form submission
loginForm.addEventListener('submit', handleLogin);
